﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PAV_PF_JorgeIsaacLopezV.Models
{
    public class DetalleVenta
    {
        public int id_Detalle { get; set; }
        public int id_Venta { get; set; }
        public int id_Cancion { get; set; }
        public int cantidad { get; set; }
        public decimal precio_Unitario { get; set; }
        public decimal subtotal { get; set; }
    }
}