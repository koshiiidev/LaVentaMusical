﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PAV_PF_JorgeIsaacLopezV.Models
{
    public class Perfil
    {
        public int id_Perfil { get; set; }
        public string nombre_Perfil { get; set; }
    }
}