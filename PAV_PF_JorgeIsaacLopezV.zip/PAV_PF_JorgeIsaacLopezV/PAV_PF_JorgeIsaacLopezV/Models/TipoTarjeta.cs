﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PAV_PF_JorgeIsaacLopezV.Models
{
    public class TipoTarjeta
    {
        public int id_TipoTarjeta { get; set; }
        public string nombre_Tarjeta { get; set; }
    }
}