﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PAV_PF_JorgeIsaacLopezV.Models
{
    public class Venta
    {
        public int id_Venta { get; set; }
        public string numero_Factura { get; set; }
        public DateTime fecha_Compra { get; set; }
        public decimal subtotal { get; set; }
        public decimal iva { get; set; }
        public decimal total { get; set; }
        public int id_Usuario { get; set; }

    }
}