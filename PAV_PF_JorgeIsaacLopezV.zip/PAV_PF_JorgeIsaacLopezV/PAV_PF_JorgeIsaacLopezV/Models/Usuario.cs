﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PAV_PF_JorgeIsaacLopezV.Models
{
    public class Usuario
    {
        public int id_Usuario { get; set; }
        public string numero_Identificacion { get; set; }
        public string nombre { get; set; }
        public string genero { get; set; }

        public string correo { get; set; }
        public int id_Tipo_Tarjeta { get; set; }
        public string numero_Tarjeta { get; set; }
        public string contraseña { get; set; }
        public int id_Perfil { get; set; }

    }
}