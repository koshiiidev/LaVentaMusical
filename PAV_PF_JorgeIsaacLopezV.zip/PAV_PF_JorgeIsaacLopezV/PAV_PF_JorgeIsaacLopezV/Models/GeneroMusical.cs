﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PAV_PF_JorgeIsaacLopezV.Models
{
    public class GeneroMusical
    {
        public int id_genero { get; set; }
        public string codigo_Genero { get; set; }
        public string descripcion { get; set; }
    }
}